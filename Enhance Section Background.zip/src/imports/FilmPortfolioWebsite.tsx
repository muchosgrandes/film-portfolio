import svgPaths from "./svg-31efjpw7nb";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import imgImageFilmProjectOneImage1 from "figma:asset/b0ff3e98d9033093a49bdb9a4c3393bb2ccc0c9a.png";
import imgImageFilmProjectTwoImage1 from "figma:asset/c67362ac360205dbd3ce05e23cfaa072bd6bf11b.png";
import imgImageFilmProjectThreeImage1 from "figma:asset/0615e521b549b53804388199c8bc95a73cf42aa8.png";
import imgImageFestival from "figma:asset/9befed21c2a6a3d17835421af645504f4845276a.png";
import imgImageMagazine from "figma:asset/a395f137d0c821e0a7ed59bffa0ae489cd0966c3.png";
import imgImagePublication from "figma:asset/645157fc5ce6f8c9b34c7c7ac2b2a59613b25d55.png";

function Container() {
  return (
    <div className="relative w-full h-full flex items-center justify-center" data-name="Container">
      {/* Hazy radial gradient background */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, #FFB3D9 0%, #FFD6E8 30%, #FFEAA4 70%, #FFF4B3 100%)',
          filter: 'blur(60px)',
          opacity: 0.9,
        }}
      />
      
      {/* Fade to black overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(to bottom, transparent 0%, transparent 40%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0.8) 90%, black 100%)',
        }}
      />
      
      {/* Content layer */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-4 sm:px-8 w-full max-w-7xl mx-auto space-y-4 sm:space-y-8">
        <p className="font-['Bricolage_Grotesque:SemiBold',sans-serif] font-semibold text-xl sm:text-2xl md:text-3xl text-white" style={{ fontVariationSettings: "'opsz' 14, 'wdth' 100" }}>
          ZWONAKA
        </p>
        <p className="font-['Bricolage_Grotesque:SemiBold',sans-serif] font-semibold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white" style={{ fontVariationSettings: "'opsz' 14, 'wdth' 100" }}>
          Filmmaker & Actress
        </p>
        <div className="bg-white px-6 sm:px-8 py-3 sm:py-4 rounded-md">
          <p className="font-['Bricolage_Grotesque:SemiBold',sans-serif] font-semibold text-xl sm:text-2xl md:text-3xl text-black" style={{ fontVariationSettings: "'opsz' 14, 'wdth' 100" }}>
            Let's explore!
          </p>
        </div>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <div className="min-h-[500px] sm:min-h-[600px] md:h-[639px] overflow-clip relative shrink-0 w-full" data-name="Hero">
      <Container />
    </div>
  );
}

function Heading() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[932px]" data-name="Heading 2">
      <p className="absolute font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold leading-[48px] left-[186px] text-[48px] text-center text-nowrap text-white top-0 translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
        Cassie’s Purpose
      </p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="absolute h-[58.5px] left-[82px] top-[724.25px] w-[768px]" data-name="Paragraph">
      <div className="absolute font-['Arial:Regular',sans-serif] leading-[29.25px] left-[-75px] not-italic text-[#9f9fa9] text-[18px] top-[-0.25px] w-[886px]">
        <p className="mb-0">An eighteen-year-old high schooler's life is changed forever when she finds a box filled with books.</p>
        <p className="mb-0">&nbsp;</p>
        <p>It is my first short film and it was inspired by the natural process in a young adult's life where they try to discover themselves. All it takes is one small thing that can spark up a purpose.</p>
      </div>
    </div>
  );
}

// Cassie's Purpose carousel images
const cassiesPurposeImages = [
  "https://i.ibb.co/ZrVZwgF/IMG-9822.jpg",
  "https://i.ibb.co/Jj89skkq/IMG-9812.jpg",
  "https://i.ibb.co/5WkRQWmb/IMG-9811.jpg",
  "https://i.ibb.co/5xFXsdpC/IMG-9813.jpg"
];

function ImageFilmProjectOneImage({ currentIndex, direction }: { currentIndex: number; direction: number }) {
  return (
    <div className="absolute h-[405px] left-0 top-0 w-[720px] overflow-hidden" data-name="Image (Film Project One - Image 1)">
      <AnimatePresence initial={false} custom={direction}>
        <motion.img
          key={currentIndex}
          custom={direction}
          alt={`Cassie's Purpose - Image ${currentIndex + 1}`}
          className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full"
          src={cassiesPurposeImages[currentIndex]}
          initial={{ x: direction > 0 ? '100%' : '-100%', opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: direction > 0 ? '-100%' : '100%', opacity: 0 }}
          transition={{
            x: { type: 'spring', stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
          }}
        />
      </AnimatePresence>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[24px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 14">
            <path d="M7 13L1 7L7 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute bg-[rgba(0,0,0,0.5)] content-stretch flex flex-col items-start left-[16px] pb-0 pt-[12px] px-[12px] rounded-[3.35544e+07px] size-[48px] top-[178.5px] cursor-pointer hover:bg-[rgba(0,0,0,0.7)] transition-colors" 
      data-name="Button"
    >
      <Icon />
    </button>
  );
}

function Icon1() {
  return (
    <div className="h-[24px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 14">
            <path d="M1 13L7 7L1 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button1({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute bg-[rgba(0,0,0,0.5)] content-stretch flex flex-col items-start left-[656px] pb-0 pt-[12px] px-[12px] rounded-[3.35544e+07px] size-[48px] top-[178.5px] cursor-pointer hover:bg-[rgba(0,0,0,0.7)] transition-colors"
      data-name="Button"
    >
      <Icon1 />
    </button>
  );
}

function Container1({ currentIndex, direction, onPrev, onNext }: { currentIndex: number; direction: number; onPrev: () => void; onNext: () => void }) {
  return (
    <div className="bg-[#18181b] h-[405px] overflow-clip relative rounded-[10px] shrink-0 w-[720px]" data-name="Container">
      <ImageFilmProjectOneImage currentIndex={currentIndex} direction={direction} />
      <Button onClick={onPrev} />
      <Button1 onClick={onNext} />
    </div>
  );
}

function Button2({ isActive, onClick }: { isActive: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-[3.35544e+07px] shrink-0 cursor-pointer transition-all ${
        isActive ? 'bg-white size-[10px]' : 'bg-[#52525c] size-[8px]'
      }`}
      data-name="Button"
      aria-label={`Go to slide ${isActive ? 'current' : ''}`}
    />
  );
}

function Button3() {
  return <div className="bg-[#52525c] rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Button" />;
}

function Container2({ currentIndex, onDotClick }: { currentIndex: number; onDotClick: (index: number) => void }) {
  return (
    <div className="h-[8px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row justify-center size-full">
        <div className="content-stretch flex gap-[7px] items-start justify-center pb-0 pl-0 pr-px pt-[-1px] relative size-full">
          {[0, 1, 2, 3].map((index) => (
            <Button2 key={index} isActive={currentIndex === index} onClick={() => onDotClick(index)} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Container3({ currentIndex }: { currentIndex: number }) {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[24px] left-[360px] not-italic text-[#71717b] text-[16px] text-center top-[-2px] translate-x-[-50%] w-[33px]">
        {currentIndex + 1} / 4
      </p>
    </div>
  );
}

function Container4() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev === 0 ? 3 : prev - 1));
  };

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev === 3 ? 0 : prev + 1));
  };

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[596.25px] items-start left-0 top-[96px] w-[932px]" data-name="Container">
      <Container1 currentIndex={currentIndex} direction={direction} onPrev={handlePrev} onNext={handleNext} />
      <Container2 currentIndex={currentIndex} onDotClick={handleDotClick} />
      <Container3 currentIndex={currentIndex} />
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[782.75px] relative shrink-0 w-full" data-name="Container">
      <Heading />
      <Paragraph />
      <Container4 />
    </div>
  );
}

function FilmProject() {
  return (
    <div className="h-[975.75px] relative shrink-0 w-full" data-name="FilmProject">
      <div aria-hidden="true" className="absolute border-[#27272a] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-0 pt-[97px] px-[24px] relative size-full">
        <Container5 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[932px]" data-name="Heading 2">
      <p className="absolute font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold leading-[48px] left-[144px] text-[48px] text-center text-nowrap text-white top-[0.25px] translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
        The Designer
      </p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="absolute h-[58.5px] left-[82px] top-[724.25px] w-[768px]" data-name="Paragraph">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[29.25px] left-[-66px] not-italic text-[#9f9fa9] text-[18px] top-0 w-[873px]">This film follows a graphic designer who tries to teeter the line between creative expression and corporate pressures. She quickly realises that it is not as easy as it seems.</p>
    </div>
  );
}

// The Designer carousel images
const theDesignerImages = [
  "https://i.ibb.co/3mHSxddZ/IMG-9807.jpg",
  "https://i.ibb.co/C3p3MWCx/IMG-9809.jpg",
  "https://i.ibb.co/zTr6Mzz3/IMG-9808.jpg",
  "https://i.ibb.co/CKYH9LxX/IMG-9810.jpg"
];

function ImageFilmProjectTwoImage({ currentIndex, direction }: { currentIndex: number; direction: number }) {
  return (
    <div className="absolute h-[524.25px] left-0 top-0 w-[932px] overflow-hidden" data-name="Image (Film Project Two - Image 1)">
      <AnimatePresence initial={false} custom={direction}>
        <motion.img
          key={currentIndex}
          custom={direction}
          alt={`The Designer - Image ${currentIndex + 1}`}
          className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full"
          src={theDesignerImages[currentIndex]}
          initial={{ x: direction > 0 ? '100%' : '-100%', opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: direction > 0 ? '-100%' : '100%', opacity: 0 }}
          transition={{
            x: { type: 'spring', stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
          }}
        />
      </AnimatePresence>
    </div>
  );
}

function Icon2() {
  return (
    <div className="h-[24px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 14">
            <path d="M7 13L1 7L7 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button4({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute bg-[rgba(0,0,0,0.5)] content-stretch flex flex-col items-start left-[16px] pb-0 pt-[12px] px-[12px] rounded-[3.35544e+07px] size-[48px] top-[238.13px] cursor-pointer hover:bg-[rgba(0,0,0,0.7)] transition-colors"
      data-name="Button"
    >
      <Icon2 />
    </button>
  );
}

function Icon3() {
  return (
    <div className="h-[24px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 14">
            <path d="M1 13L7 7L1 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button5({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute bg-[rgba(0,0,0,0.5)] content-stretch flex flex-col items-start left-[868px] pb-0 pt-[12px] px-[12px] rounded-[3.35544e+07px] size-[48px] top-[238.13px] cursor-pointer hover:bg-[rgba(0,0,0,0.7)] transition-colors"
      data-name="Button"
    >
      <Icon3 />
    </button>
  );
}

function Container6({ currentIndex, direction, onPrev, onNext }: { currentIndex: number; direction: number; onPrev: () => void; onNext: () => void }) {
  return (
    <div className="bg-[#18181b] h-[524.25px] overflow-clip relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <ImageFilmProjectTwoImage currentIndex={currentIndex} direction={direction} />
      <Button4 onClick={onPrev} />
      <Button5 onClick={onNext} />
    </div>
  );
}

function Button6({ isActive, onClick }: { isActive: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-[3.35544e+07px] shrink-0 cursor-pointer transition-all ${
        isActive ? 'bg-white size-[10px]' : 'bg-[#52525c] size-[8px]'
      }`}
      data-name="Button"
      aria-label={`Go to slide ${isActive ? 'current' : ''}`}
    />
  );
}

function Button7() {
  return <div className="bg-[#52525c] rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Button" />;
}

function Container7({ currentIndex, onDotClick }: { currentIndex: number; onDotClick: (index: number) => void }) {
  return (
    <div className="h-[8px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row justify-center size-full">
        <div className="content-stretch flex gap-[7px] items-start justify-center pb-0 pl-0 pr-px pt-[-1px] relative size-full">
          {[0, 1, 2, 3].map((index) => (
            <Button6 key={index} isActive={currentIndex === index} onClick={() => onDotClick(index)} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Container8({ currentIndex }: { currentIndex: number }) {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[24px] left-[466.38px] not-italic text-[#71717b] text-[16px] text-center top-[-2px] translate-x-[-50%] w-[33px]">
        {currentIndex + 1} / 4
      </p>
    </div>
  );
}

function Container9() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev === 0 ? 3 : prev - 1));
  };

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev === 3 ? 0 : prev + 1));
  };

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[596.25px] items-start left-0 top-[96px] w-[932px]" data-name="Container">
      <Container6 currentIndex={currentIndex} direction={direction} onPrev={handlePrev} onNext={handleNext} />
      <Container7 currentIndex={currentIndex} onDotClick={handleDotClick} />
      <Container8 currentIndex={currentIndex} />
    </div>
  );
}

function Container10() {
  return (
    <div className="h-[782.75px] relative shrink-0 w-full" data-name="Container">
      <Heading1 />
      <Paragraph1 />
      <Container9 />
    </div>
  );
}

function FilmProject1() {
  return (
    <div className="h-[975.75px] relative shrink-0 w-full" data-name="FilmProject">
      <div aria-hidden="true" className="absolute border-[#27272a] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-0 pt-[97px] px-[24px] relative size-full">
        <Container10 />
      </div>
    </div>
  );
}

function Heading2() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[932px]" data-name="Heading 2">
      <p className="absolute font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold leading-[48px] left-[168.5px] text-[48px] text-center text-nowrap text-white top-[0.5px] translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
        The Silent Killer
      </p>
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="absolute h-[58.5px] left-[82px] top-[724.25px] w-[768px]" data-name="Paragraph">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[29.25px] left-[-73px] not-italic text-[#9f9fa9] text-[18px] top-[-20.75px] w-[880px]">After the sudden and inexplained death of her husband, Hulisani becomes consumed by suspicion and grief. Determined to uncover the truth, she confronts anyone and everyone that she believes may be hiding something. As she digs deeper, the line between truth and obsession begins to blur - until a life-changing revelation forces her to face the one person she has never questioned: herself.</p>
    </div>
  );
}

// The Silent Killer carousel images
const theSilentKillerImages = [
  "https://i.ibb.co/R4V6dfyB/IMG-9802.jpg",
  "https://i.ibb.co/Hw7PPsj/IMG-9803.jpg",
  "https://i.ibb.co/pvR0xJ4P/IMG-9804.jpg",
  "https://i.ibb.co/h64W8rh/IMG-9805.jpg"
];

function ImageFilmProjectThreeImage({ currentIndex, direction }: { currentIndex: number; direction: number }) {
  return (
    <div className="absolute h-[524.25px] left-0 top-0 w-[932px] overflow-hidden" data-name="Image (Film Project Three - Image 1)">
      <AnimatePresence initial={false} custom={direction}>
        <motion.img
          key={currentIndex}
          custom={direction}
          alt={`The Silent Killer - Image ${currentIndex + 1}`}
          className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full"
          src={theSilentKillerImages[currentIndex]}
          initial={{ x: direction > 0 ? '100%' : '-100%', opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: direction > 0 ? '-100%' : '100%', opacity: 0 }}
          transition={{
            x: { type: 'spring', stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 }
          }}
        />
      </AnimatePresence>
    </div>
  );
}

function Icon4() {
  return (
    <div className="h-[24px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 14">
            <path d="M7 13L1 7L7 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button8({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute bg-[rgba(0,0,0,0.5)] content-stretch flex flex-col items-start left-[16px] pb-0 pt-[12px] px-[12px] rounded-[3.35544e+07px] size-[48px] top-[238.13px] cursor-pointer hover:bg-[rgba(0,0,0,0.7)] transition-colors"
      data-name="Button"
    >
      <Icon4 />
    </button>
  );
}

function Icon5() {
  return (
    <div className="h-[24px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute bottom-1/4 left-[37.5%] right-[37.5%] top-1/4" data-name="Vector">
        <div className="absolute inset-[-8.33%_-16.67%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 14">
            <path d="M1 13L7 7L1 1" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button9({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="absolute bg-[rgba(0,0,0,0.5)] content-stretch flex flex-col items-start left-[868px] pb-0 pt-[12px] px-[12px] rounded-[3.35544e+07px] size-[48px] top-[238.13px] cursor-pointer hover:bg-[rgba(0,0,0,0.7)] transition-colors"
      data-name="Button"
    >
      <Icon5 />
    </button>
  );
}

function Container11({ currentIndex, direction, onPrev, onNext }: { currentIndex: number; direction: number; onPrev: () => void; onNext: () => void }) {
  return (
    <div className="bg-[#18181b] h-[524.25px] overflow-clip relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <ImageFilmProjectThreeImage currentIndex={currentIndex} direction={direction} />
      <Button8 onClick={onPrev} />
      <Button9 onClick={onNext} />
    </div>
  );
}

function Button10({ isActive, onClick }: { isActive: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-[3.35544e+07px] shrink-0 cursor-pointer transition-all ${
        isActive ? 'bg-white size-[10px]' : 'bg-[#52525c] size-[8px]'
      }`}
      data-name="Button"
      aria-label={`Go to slide ${isActive ? 'current' : ''}`}
    />
  );
}

function Button11() {
  return <div className="bg-[#52525c] rounded-[3.35544e+07px] shrink-0 size-[8px]" data-name="Button" />;
}

function Container12({ currentIndex, onDotClick }: { currentIndex: number; onDotClick: (index: number) => void }) {
  return (
    <div className="h-[8px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row justify-center size-full">
        <div className="content-stretch flex gap-[7px] items-start justify-center pb-0 pl-0 pr-px pt-[-1px] relative size-full">
          {[0, 1, 2, 3].map((index) => (
            <Button10 key={index} isActive={currentIndex === index} onClick={() => onDotClick(index)} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Container13({ currentIndex }: { currentIndex: number }) {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[24px] left-[466.38px] not-italic text-[#71717b] text-[16px] text-center top-[-2px] translate-x-[-50%] w-[33px]">
        {currentIndex + 1} / 4
      </p>
    </div>
  );
}

function Container14() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev === 0 ? 3 : prev - 1));
  };

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev === 3 ? 0 : prev + 1));
  };

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[596.25px] items-start left-0 top-[96px] w-[932px]" data-name="Container">
      <Container11 currentIndex={currentIndex} direction={direction} onPrev={handlePrev} onNext={handleNext} />
      <Container12 currentIndex={currentIndex} onDotClick={handleDotClick} />
      <Container13 currentIndex={currentIndex} />
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[782.75px] relative shrink-0 w-full" data-name="Container">
      <Heading2 />
      <Paragraph2 />
      <Container14 />
    </div>
  );
}

function FilmProject2() {
  return (
    <div className="h-[975.75px] relative shrink-0 w-full" data-name="FilmProject">
      <div aria-hidden="true" className="absolute border-[#27272a] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-0 pt-[97px] px-[24px] relative size-full">
        <Container15 />
      </div>
    </div>
  );
}

function Heading3() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[932px]" data-name="Heading 2">
      <p className="absolute font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold leading-[48px] left-[466.53px] text-[48px] text-center text-nowrap text-white top-[-5px] translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
        Featured In:
      </p>
    </div>
  );
}

function ImageFestival() {
  return (
    <div className="h-[188px] relative shrink-0 w-full" data-name="Image (Festival)">
      <img alt="First-Time Filmmaker Sessions Volume 1" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src="https://i.ibb.co/hJgHpXpf/IMG-9816.png" />
    </div>
  );
}

function Container16() {
  return (
    <div className="basis-0 bg-black grow min-h-px min-w-px relative rounded-[3.35544e+07px] shrink-0 w-[192px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip p-[2px] relative rounded-[inherit] size-full">
        <ImageFestival />
      </div>
      <div aria-hidden="true" className="absolute border-2 border-[#27272a] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="h-[24px] relative shrink-0 w-[51.953px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid font-['Arial:Regular',sans-serif] leading-[0] not-italic relative size-full text-[#71717b] text-[16px] text-center text-nowrap">
        <div className="absolute leading-[24px] left-[calc(50%+0.17px)] top-[-6.25px] translate-x-[-50%]">
          <p className="mb-0">First-Time</p>
          <p className="mb-0">Filmmaker Sessions</p>
          <p>Volume 13</p>
        </div>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[232px] items-center left-0 top-0 w-[266.656px]" data-name="Container">
      <Container16 />
      <Paragraph3 />
    </div>
  );
}

function ImageMagazine() {
  return (
    <div className="h-[188px] relative shrink-0 w-full" data-name="Image (Magazine)">
      <img alt="Bijou Film Festival" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src="https://i.ibb.co/DH9PCKXX/IMG-9815.png" />
    </div>
  );
}

function Container18() {
  return (
    <div className="basis-0 bg-black grow min-h-px min-w-px relative rounded-[3.35544e+07px] shrink-0 w-[192px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip p-[2px] relative rounded-[inherit] size-full">
        <ImageMagazine />
      </div>
      <div aria-hidden="true" className="absolute border-2 border-[#27272a] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
    </div>
  );
}

function Paragraph4() {
  return (
    <div className="h-[24px] relative shrink-0 w-[68.609px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <div className="absolute font-['Arial:Regular',sans-serif] leading-[24px] left-[41.31px] not-italic text-[#71717b] text-[16px] text-center text-nowrap top-[-6.25px] translate-x-[-50%]">
          <p className="mb-0">{`Bijou `}</p>
          <p>Film Festival</p>
        </div>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[232px] items-center left-[314.66px] top-0 w-[266.672px]" data-name="Container">
      <Container18 />
      <Paragraph4 />
    </div>
  );
}

function ImagePublication() {
  return (
    <div className="h-[188px] relative shrink-0 w-full" data-name="Image (Publication)">
      <img alt="Publication" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src="https://i.ibb.co/KxzCZj6Z/IMG-9817.png" />
    </div>
  );
}

function Container20() {
  return (
    <div className="basis-0 bg-black grow min-h-px min-w-px relative rounded-[3.35544e+07px] shrink-0 w-[192px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip p-[2px] relative rounded-[inherit] size-full">
        <ImagePublication />
      </div>
      <div aria-hidden="true" className="absolute border-2 border-[#27272a] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
    </div>
  );
}

function Paragraph5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[51.953px]" data-name="Paragraph">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid font-['Arial:Regular',sans-serif] leading-[0] not-italic relative size-full text-[#71717b] text-[16px] text-center text-nowrap">
        <div className="absolute leading-[24px] left-[calc(50%+0.17px)] top-[-6.25px] translate-x-[-50%]">
          <p className="mb-0">First-Time</p>
          <p className="mb-0">Filmmaker Sessions</p>
          <p>Volume 2</p>
        </div>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[232px] items-center left-[629.33px] top-0 w-[266.656px]" data-name="Container">
      <Container20 />
      <Paragraph5 />
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute h-[232px] left-[18px] top-[112px] w-[896px]" data-name="Container">
      <Container17 />
      <Container19 />
      <Container21 />
    </div>
  );
}

function Container23() {
  return (
    <div className="h-[344px] relative shrink-0 w-full" data-name="Container">
      <Heading3 />
      <Container22 />
    </div>
  );
}

function FeaturedIn() {
  return (
    <div className="h-[537px] relative shrink-0 w-full" data-name="FeaturedIn">
      <div aria-hidden="true" className="absolute border-[#27272a] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-0 pt-[97px] px-[24px] relative size-full">
        <Container23 />
      </div>
    </div>
  );
}

function Heading4() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[896px]" data-name="Heading 2">
      <p className="absolute font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold leading-[48px] left-[448px] text-[48px] text-center text-nowrap text-white top-[-5.25px] translate-x-[-50%]" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
        Contact Me!
      </p>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Icon">
          <path d={svgPaths.p15fdbe00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d={svgPaths.p118ec100} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
          <path d="M29.1667 10.8333H29.1833" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
        </g>
      </svg>
    </div>
  );
}

function Link() {
  return (
    <a 
      href="https://www.instagram.com/shotbyzwonakaaaaa" 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-[#18181b] relative rounded-[3.35544e+07px] shrink-0 size-[80px]" 
      data-name="Link"
    >
      <div aria-hidden="true" className="absolute border-2 border-[#27272a] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[2px] relative size-full">
        <Icon6 />
      </div>
    </a>
  );
}

function TikTokIcon() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="TikTokIcon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="TikTokIcon">
          <path d={svgPaths.p3cedca00} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Link1() {
  return (
    <a 
      href="https://www.tiktok.com/shotbyzwonakaaaaa" 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-[#18181b] relative rounded-[3.35544e+07px] shrink-0 size-[80px]" 
      data-name="Link"
    >
      <div aria-hidden="true" className="absolute border-2 border-[#27272a] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[2px] relative size-full">
        <TikTokIcon />
      </div>
    </a>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="Icon" transform="translate(0, -2)">
          {/* YouTube outline - larger and positioned higher */}
          <path d="M36 16C36 16 35.6 13.4 34.5 12.3C33.1 10.9 31.5 10.9 30.8 10.8C25.8 10.4 20 10.4 20 10.4C20 10.4 14.2 10.4 9.2 10.8C8.5 10.9 6.9 10.9 5.5 12.3C4.4 13.4 4 16 4 16C4 16 3.6 18.9 3.6 21.8V24.6C3.6 27.5 4 30.4 4 30.4C4 30.4 4.4 33 5.5 34.1C6.9 35.5 8.7 35.5 9.5 35.6C12.5 35.9 20 36 20 36C20 36 25.8 35.9 30.8 35.5C31.5 35.4 33.1 35.4 34.5 34C35.6 32.9 36 30.3 36 30.3C36 30.3 36.4 27.4 36.4 24.5V21.7C36.4 18.8 36 16 36 16Z" 
            stroke="var(--stroke-0, white)" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2.2" />
          {/* Play button - larger and positioned higher */}
          <path d="M16 28L28 21.5L16 15V28Z" 
            stroke="var(--stroke-0, white)" 
            fill="var(--fill-0, white)"
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Link2() {
  return (
    <a 
      href="https://www.youtube.com/@zwonakaaaaa" 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-[#18181b] relative rounded-[3.35544e+07px] shrink-0 size-[80px]" 
      data-name="Link"
    >
      <div aria-hidden="true" className="absolute border-2 border-[#27272a] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[2px] relative size-full">
        <Icon7 />
      </div>
    </a>
  );
}

function Container24() {
  return (
    <div className="absolute content-stretch flex gap-[32px] h-[80px] items-start justify-center left-0 top-[112px] w-[896px]" data-name="Container">
      <Link />
      <Link2 />
      <Link1 />
    </div>
  );
}

function Label() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arial:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-black text-[14px]">Name</p>
    </div>
  );
}

function TextInput() {
  return (
    <div className="bg-[#18181b] h-[50px] relative rounded-[10px] shrink-0 w-full" data-name="Text Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[16px] py-[12px] relative size-full">
          <p className="font-['Arial:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-[rgba(255,255,255,0.5)] text-nowrap">Your name</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Container25() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[78px] items-start relative shrink-0 w-full" data-name="Container">
      <Label />
      <TextInput />
    </div>
  );
}

function Label1() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arial:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-black text-[14px]">Email Address</p>
    </div>
  );
}

function EmailInput() {
  return (
    <div className="bg-[#18181b] h-[50px] relative rounded-[10px] shrink-0 w-full" data-name="Email Input">
      <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-center px-[16px] py-[12px] relative size-full">
          <p className="font-['Arial:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-[rgba(255,255,255,0.5)] text-nowrap">your.email@example.com</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[78px] items-start relative shrink-0 w-full" data-name="Container">
      <Label1 />
      <EmailInput />
    </div>
  );
}

function Label2() {
  return (
    <div className="content-stretch flex h-[20px] items-start relative shrink-0 w-full" data-name="Label">
      <p className="basis-0 font-['Arial:Regular',sans-serif] grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-black text-[14px]">Message</p>
    </div>
  );
}

function TextArea() {
  return (
    <div className="bg-[#18181b] h-[170px] relative rounded-[10px] shrink-0 w-full" data-name="Text Area">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex items-start px-[16px] py-[12px] relative size-full">
          <p className="font-['Arial:Regular',sans-serif] leading-[24px] not-italic relative shrink-0 text-[16px] text-[rgba(255,255,255,0.5)] text-nowrap">Your message...</p>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[#27272a] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] h-[204px] items-start relative shrink-0 w-full" data-name="Container">
      <Label2 />
      <TextArea />
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-white h-[48px] relative rounded-[10px] shrink-0 w-full" data-name="Button">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[24px] left-[336.52px] not-italic text-[16px] text-black text-center text-nowrap top-[10px] translate-x-[-50%]">Send Message</p>
    </div>
  );
}

function Form() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] h-[480px] items-start left-[112px] top-[256px] w-[672px]" data-name="Form">
      <Container25 />
      <Container26 />
      <Container27 />
      <Button12 />
    </div>
  );
}

function Paragraph6() {
  return (
    <div className="h-[24px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Arial:Regular',sans-serif] leading-[24px] left-[448.02px] not-italic text-[#52525c] text-[16px] text-center text-nowrap top-[-2px] translate-x-[-50%]">© 2026 Zwonaka. All rights reserved.</p>
    </div>
  );
}

function Container28() {
  return (
    <div className="absolute content-stretch flex flex-col h-[57px] items-start left-0 pb-0 pt-[33px] px-0 top-[800px] w-[896px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#27272a] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Paragraph6 />
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[857px] relative shrink-0 w-full" data-name="Container">
      <Heading4 />
      <Container24 />
      <Form />
      <Container28 />
    </div>
  );
}

function Contact() {
  return (
    <div className="h-[1050px] relative shrink-0 w-full" data-name="Contact">
      {/* Hazy radial gradient background */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(circle at center, #FFB3D9 0%, #FFD6E8 30%, #FFEAA4 70%, #FFF4B3 100%)',
          filter: 'blur(60px)',
          opacity: 0.9,
        }}
      />
      
      {/* Fade from black overlay at top */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(to bottom, black 0%, rgba(0,0,0,0.8) 10%, rgba(0,0,0,0.3) 30%, transparent 60%, transparent 100%)',
        }}
      />
      
      <div aria-hidden="true" className="absolute border-[#27272a] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start pb-0 pt-[97px] px-[42px] relative size-full">
        <Container29 />
      </div>
    </div>
  );
}

function App() {
  return (
    <div className="bg-black content-stretch flex flex-col h-[5153.25px] items-start relative shrink-0 w-full" data-name="App">
      <Hero />
      <FilmProject />
      <FilmProject1 />
      <FilmProject2 />
      <FeaturedIn />
      <Contact />
    </div>
  );
}

export default function FilmPortfolioWebsite() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start relative size-full" data-name="Film Portfolio Website">
      <App />
    </div>
  );
}