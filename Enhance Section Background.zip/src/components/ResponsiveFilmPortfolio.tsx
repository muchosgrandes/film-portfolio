import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import svgPaths from '../imports/svg-31efjpw7nb';

// Image arrays
const cassiesPurposeImages = [
  "https://i.ibb.co/ZrVZwgF/IMG-9822.jpg",
  "https://i.ibb.co/Jj89skkq/IMG-9812.jpg",
  "https://i.ibb.co/5WkRQWmb/IMG-9811.jpg",
  "https://i.ibb.co/5xFXsdpC/IMG-9813.jpg"
];

const theDesignerImages = [
  "https://i.ibb.co/3mHSxddZ/IMG-9807.jpg",
  "https://i.ibb.co/C3p3MWCx/IMG-9809.jpg",
  "https://i.ibb.co/zTr6Mzz3/IMG-9808.jpg",
  "https://i.ibb.co/CKYH9LxX/IMG-9810.jpg"
];

const theSilentKillerImages = [
  "https://i.ibb.co/R4V6dfyB/IMG-9802.jpg",
  "https://i.ibb.co/Hw7PPsj/IMG-9803.jpg",
  "https://i.ibb.co/pvR0xJ4P/IMG-9804.jpg",
  "https://i.ibb.co/h64W8rh/IMG-9805.jpg"
];

// Carousel Component
function Carousel({ images, alt, aspectRatio = "16/9" }: { images: string[]; alt: string; aspectRatio?: string }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const handlePrev = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Carousel Container */}
      <div className="relative w-full bg-[#18181b] rounded-lg overflow-hidden" style={{ aspectRatio }}>
        <AnimatePresence initial={false} custom={direction}>
          <motion.img
            key={currentIndex}
            custom={direction}
            alt={`${alt} - Image ${currentIndex + 1}`}
            className="absolute inset-0 w-full h-full object-cover"
            src={images[currentIndex]}
            initial={{ x: direction > 0 ? '100%' : '-100%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: direction > 0 ? '-100%' : '100%', opacity: 0 }}
            transition={{
              x: { type: 'spring', stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
          />
        </AnimatePresence>

        {/* Navigation Buttons */}
        <button
          onClick={handlePrev}
          className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 bg-[rgba(0,0,0,0.5)] hover:bg-[rgba(0,0,0,0.7)] rounded-full p-2 sm:p-3 transition-colors z-10"
          aria-label="Previous image"
        >
          <svg className="w-4 h-4 sm:w-6 sm:h-6" fill="none" viewBox="0 0 8 14">
            <path d="M7 13L1 7L7 1" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </button>

        <button
          onClick={handleNext}
          className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 bg-[rgba(0,0,0,0.5)] hover:bg-[rgba(0,0,0,0.7)] rounded-full p-2 sm:p-3 transition-colors z-10"
          aria-label="Next image"
        >
          <svg className="w-4 h-4 sm:w-6 sm:h-6" fill="none" viewBox="0 0 8 14">
            <path d="M1 13L7 7L1 1" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          </svg>
        </button>
      </div>

      {/* Dots Navigation */}
      <div className="flex justify-center items-center gap-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => handleDotClick(index)}
            className={`rounded-full transition-all ${
              currentIndex === index ? 'bg-white w-2.5 h-2.5' : 'bg-[#52525c] w-2 h-2'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Counter */}
      <p className="text-center text-[#71717b] text-sm">
        {currentIndex + 1} / {images.length}
      </p>
    </div>
  );
}

export default function ResponsiveFilmPortfolio() {
  const handleExploreClick = () => {
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="bg-black min-h-screen w-full">
      {/* Hero Section */}
      <section className="relative min-h-[500px] sm:min-h-[600px] lg:min-h-[700px] w-full overflow-hidden flex items-center justify-center">
        {/* Video Background */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
          src="https://res.cloudinary.com/dctojb9qj/video/upload/v1767947921/video-output-886A056D-9693-4ADE-BE4D-2A1E4260EE37-1_w8rnq9.mp4"
          onLoadedData={(e) => {
            const video = e.currentTarget;
            video.play().catch(err => console.log('Video autoplay failed:', err));
          }}
        />
        
        {/* Fade to black overlay */}
        <div 
          className="absolute inset-0 z-[2]"
          style={{
            background: 'linear-gradient(to bottom, transparent 0%, transparent 40%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0.8) 90%, black 100%)',
          }}
        />
        
        {/* Content */}
        <div className="relative z-10 flex flex-col items-center justify-center text-center px-4 sm:px-8 w-full max-w-7xl mx-auto space-y-6 sm:space-y-8">
          <p className="font-['Bricolage_Grotesque:SemiBold',sans-serif] font-semibold text-xl sm:text-2xl md:text-3xl text-white" style={{ fontVariationSettings: "'opsz' 14, 'wdth' 100" }}>
            ZWONAKA
          </p>
          <h1 className="font-['Bricolage_Grotesque:SemiBold',sans-serif] font-semibold text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white px-4" style={{ fontVariationSettings: "'opsz' 14, 'wdth' 100" }}>
            Filmmaker & Actress
          </h1>
          <button 
            onClick={handleExploreClick}
            className="bg-white px-6 sm:px-8 md:px-10 py-3 sm:py-4 rounded-md cursor-pointer hover:bg-gray-100 transition-colors"
          >
            <p className="font-['Bricolage_Grotesque:SemiBold',sans-serif] font-semibold text-xl sm:text-2xl md:text-3xl text-black" style={{ fontVariationSettings: "'opsz' 14, 'wdth' 100" }}>
              Let's explore!
            </p>
          </button>
        </div>
      </section>

      {/* Film Project 1: Cassie's Purpose */}
      <section id="projects" className="border-t border-[#27272a] py-12 sm:py-16 lg:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto space-y-8 sm:space-y-12">
          <h2 className="font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold text-3xl sm:text-4xl md:text-5xl text-white text-center" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
            Cassie's Purpose
          </h2>
          
          <div className="text-[#9f9fa9] text-base sm:text-lg max-w-4xl mx-auto space-y-4 text-center px-4">
            <p>An eighteen-year-old high schooler's life is changed forever when she finds a box filled with books.</p>
            <p>It is my first short film and it was inspired by the natural process in a young adult's life where they try to discover themselves. All it takes is one small thing that can spark up a purpose.</p>
          </div>

          <Carousel images={cassiesPurposeImages} alt="Cassie's Purpose" aspectRatio="16/9" />
        </div>
      </section>

      {/* Film Project 2: The Designer */}
      <section className="border-t border-[#27272a] py-12 sm:py-16 lg:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto space-y-8 sm:space-y-12">
          <h2 className="font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold text-3xl sm:text-4xl md:text-5xl text-white text-center" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
            The Designer
          </h2>
          
          <p className="text-[#9f9fa9] text-base sm:text-lg max-w-4xl mx-auto text-center px-4">
            This film follows a graphic designer who tries to teeter the line between creative expression and corporate pressures. She quickly realises that it is not as easy as it seems.
          </p>

          <Carousel images={theDesignerImages} alt="The Designer" aspectRatio="16/9" />
        </div>
      </section>

      {/* Film Project 3: The Silent Killer */}
      <section className="border-t border-[#27272a] py-12 sm:py-16 lg:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto space-y-8 sm:space-y-12">
          <h2 className="font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold text-3xl sm:text-4xl md:text-5xl text-white text-center" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
            The Silent Killer
          </h2>
          
          <p className="text-[#9f9fa9] text-base sm:text-lg max-w-4xl mx-auto text-center px-4">
            After the sudden and inexplained death of her husband, Hulisani becomes consumed by suspicion and grief. Determined to uncover the truth, she confronts anyone and everyone that she believes may be hiding something. As she digs deeper, the line between truth and obsession begins to blur - until a life-changing revelation forces her to face the one person she has never questioned: herself.
          </p>

          <Carousel images={theSilentKillerImages} alt="The Silent Killer" aspectRatio="16/9" />
        </div>
      </section>

      {/* Featured In Section */}
      <section className="border-t border-[#27272a] py-12 sm:py-16 lg:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto space-y-8 sm:space-y-12">
          <h2 className="font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold text-3xl sm:text-4xl md:text-5xl text-white text-center" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
            Featured In:
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-12 max-w-4xl mx-auto">
            {/* Circle 1 */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full bg-black border-2 border-[#27272a] p-1 overflow-hidden">
                <img 
                  src="https://i.ibb.co/hJgHpXpf/IMG-9816.png" 
                  alt="First-Time Filmmaker Sessions Volume 13" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="text-[#71717b] text-sm text-center leading-6">
                <p className="mb-0">First-Time</p>
                <p className="mb-0">Filmmaker Sessions</p>
                <p className="mb-0">Volume 13</p>
              </div>
            </div>

            {/* Circle 2 */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full bg-black border-2 border-[#27272a] p-1 overflow-hidden">
                <img 
                  src="https://i.ibb.co/DH9PCKXX/IMG-9815.png" 
                  alt="Bijou Film Festival" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="text-[#71717b] text-sm text-center leading-6">
                <p className="mb-0">Bijou</p>
                <p className="mb-0">Film Festival</p>
              </div>
            </div>

            {/* Circle 3 */}
            <div className="flex flex-col items-center gap-4 sm:col-span-2 lg:col-span-1">
              <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full bg-black border-2 border-[#27272a] p-1 overflow-hidden">
                <img 
                  src="https://i.ibb.co/KxzCZj6Z/IMG-9817.png" 
                  alt="First-Time Filmmaker Sessions Volume 2" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="text-[#71717b] text-sm text-center leading-6">
                <p className="mb-0">First-Time</p>
                <p className="mb-0">Filmmaker Sessions</p>
                <p className="mb-0">Volume 2</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="relative border-t border-[#27272a] py-12 sm:py-16 lg:py-24 px-4 sm:px-6 lg:px-8 min-h-[800px]">
        {/* Gradient Background */}
        <div 
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(circle at center, #FFB3D9 0%, #FFD6E8 30%, #FFEAA4 70%, #FFF4B3 100%)',
            filter: 'blur(60px)',
            opacity: 0.9,
          }}
        />
        
        {/* Fade from black overlay at top */}
        <div 
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to bottom, black 0%, rgba(0,0,0,0.8) 10%, rgba(0,0,0,0.3) 30%, transparent 60%, transparent 100%)',
          }}
        />

        <div className="relative z-10 max-w-3xl mx-auto space-y-8 sm:space-y-12">
          <h2 className="font-['Bricolage_Grotesque:96pt_ExtraBold',sans-serif] font-extrabold text-3xl sm:text-4xl md:text-5xl text-white text-center" style={{ fontVariationSettings: "'opsz' 96, 'wdth' 100" }}>
            Contact Me!
          </h2>
          
          {/* Social Media Links */}
          <div className="flex justify-center items-center gap-6 sm:gap-8">
            <a 
              href="https://www.instagram.com/shotbyzwonakaaaaa" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-[#18181b] border-2 border-[#27272a] rounded-full w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center hover:bg-[#27272a] transition-colors"
            >
              <svg className="w-8 h-8 sm:w-10 sm:h-10" fill="none" viewBox="0 0 40 40">
                <path d={svgPaths.p15fdbe00} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
                <path d={svgPaths.p118ec100} stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
                <path d="M29.1667 10.8333H29.1833" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3.33333" />
              </svg>
            </a>

            <a 
              href="https://www.youtube.com/@zwonakaaaaa" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-[#18181b] border-2 border-[#27272a] rounded-full w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center hover:bg-[#27272a] transition-colors"
            >
              <svg className="w-8 h-8 sm:w-10 sm:h-10" fill="none" viewBox="0 0 40 40">
                <g transform="translate(0, -2)">
                  <path d="M36 16C36 16 35.6 13.4 34.5 12.3C33.1 10.9 31.5 10.9 30.8 10.8C25.8 10.4 20 10.4 20 10.4C20 10.4 14.2 10.4 9.2 10.8C8.5 10.9 6.9 10.9 5.5 12.3C4.4 13.4 4 16 4 16C4 16 3.6 18.9 3.6 21.8V24.6C3.6 27.5 4 30.4 4 30.4C4 30.4 4.4 33 5.5 34.1C6.9 35.5 8.7 35.5 9.5 35.6C12.5 35.9 20 36 20 36C20 36 25.8 35.9 30.8 35.5C31.5 35.4 33.1 35.4 34.5 34C35.6 32.9 36 30.3 36 30.3C36 30.3 36.4 27.4 36.4 24.5V21.7C36.4 18.8 36 16 36 16Z" stroke="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.2" />
                  <path d="M16 28L28 21.5L16 15V28Z" stroke="white" fill="white" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
                </g>
              </svg>
            </a>

            <a 
              href="https://www.tiktok.com/shotbyzwonakaaaaa" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-[#18181b] border-2 border-[#27272a] rounded-full w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center hover:bg-[#27272a] transition-colors"
            >
              <svg className="w-8 h-8 sm:w-10 sm:h-10" fill="none" viewBox="0 0 40 40">
                <path d={svgPaths.p3cedca00} fill="white" />
              </svg>
            </a>
          </div>

          {/* Contact Form */}
          <form className="space-y-6">
            <div className="space-y-2">
              <label className="block text-black text-sm font-['Arial:Regular',sans-serif]">Name</label>
              <input 
                type="text" 
                placeholder="Your name"
                className="w-full bg-[#18181b] border border-[#27272a] rounded-lg px-4 py-3 text-white placeholder:text-[rgba(255,255,255,0.5)] focus:outline-none focus:border-white transition-colors"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-black text-sm font-['Arial:Regular',sans-serif]">Email Address</label>
              <input 
                type="email" 
                placeholder="your.email@example.com"
                className="w-full bg-[#18181b] border border-[#27272a] rounded-lg px-4 py-3 text-white placeholder:text-[rgba(255,255,255,0.5)] focus:outline-none focus:border-white transition-colors"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-black text-sm font-['Arial:Regular',sans-serif]">Message</label>
              <textarea 
                placeholder="Your message..."
                rows={5}
                className="w-full bg-[#18181b] border border-[#27272a] rounded-lg px-4 py-3 text-white placeholder:text-[rgba(255,255,255,0.5)] focus:outline-none focus:border-white transition-colors resize-none"
              />
            </div>

            <button 
              type="submit"
              className="w-full bg-white text-black rounded-lg px-6 py-3 font-['Arial:Regular',sans-serif] hover:bg-gray-200 transition-colors"
            >
              Send Message
            </button>
          </form>

          {/* Footer */}
          <div className="border-t border-[#27272a] pt-8">
            <p className="text-[#52525c] text-sm text-center">
              © 2026 Zwonaka. All rights reserved.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}